    </main>
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> All rights reserved.</p>
        </div>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>